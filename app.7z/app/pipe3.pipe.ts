import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipe3'
})
export class Pipe3Pipe implements PipeTransform {

  transform(arr:any[],column:string,order:boolean){
    //
    // column name is not defined ,no sorting is done
    //
     if(column==undefined){
         return arr;
     }

      let result:any[]; 
     if(order){
       result =this.ascending(arr,column);
       }else{
         result =this.descending(arr,column);
          }
       return result;
 }

 /**
  * 
  * @param arr  array which needs to be sorted
  * @param column column name which is used for sorting
  */
 ascending(arr:any[],column:string){
     arr.sort((a:any,b:any)=>{
         if(a[column]>b[column]){
             return 1;
         }
         return -1;
     });
     return arr;
 }

/**
  * 
  * @param arr  array which needs to be sorted
  * @param column column name which is used for sorting
    */
 descending(arr:any[],column:string){
     arr.sort((a:any,b:any)=>{
         if(a[column]>b[column]){
             return -1;
         }
         return 1;
     });
     return arr;
 }
}