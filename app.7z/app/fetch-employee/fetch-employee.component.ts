import { Component, OnInit } from '@angular/core';
import { MyserviceService, Employee } from '../myservice.service';

@Component({
  selector: 'app-fetch-employee',
  templateUrl: './fetch-employee.component.html',
  styleUrls: ['./fetch-employee.component.css']
})
export class FetchEmployeeComponent implements OnInit {
  service:MyserviceService;
  

  constructor(service:MyserviceService) { 
    this.service=service;
    }
    employees:Employee[]=[]
    delete(id:number){
      this.service.delete(id);
      this.employees=this.service.getEmployees();
    }
    column:string="id"; 
    order:boolean=true;
    sort(column:string){
    
      if(this.column==column )
      {
        this.order=!this.order;
      }else{
        this.order=true;
        this.column=column;
      }
    }

  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }}