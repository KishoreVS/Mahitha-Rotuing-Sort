import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { FetchEmployeeComponent } from './fetch-employee/fetch-employee.component';
import { HttpClient,HttpClientModule} from '@angular/common/http';
import{FormsModule} from '@angular/forms'


import { MyserviceService } from './myservice.service';
import { Pipe3Pipe } from './pipe3.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AddEmployeeComponent,
    FetchEmployeeComponent,
    Pipe3Pipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
