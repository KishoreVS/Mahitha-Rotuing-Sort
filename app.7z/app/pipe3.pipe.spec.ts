import { Pipe3Pipe } from './pipe3.pipe';

describe('Pipe3Pipe', () => {
  it('create an instance', () => {
    const pipe = new Pipe3Pipe();
    expect(pipe).toBeTruthy();
  });
});
