import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  http:HttpClient;
  employees:Employee[]=[];

  constructor(http:HttpClient) { 
    this.http=http;
  }
  fetched:boolean=false;
  fetchEmployees(){
    this.http.get('./assets/abc.json').subscribe(
      data=>{
        if(!this.fetched){
          this.convert(data);
          this.fetched=true;
        }});}
      
  getEmployees():Employee[]{
    return this.employees;
  }
  convert(data:any){
    for(let o of data){
      let e=new Employee(o.id,o.name,o.designation,o.address,o.contact,o.salary);
      this.employees.push(e);
    }
  }
  delete(id:number)
        {
          let foundIndex:number=-1;
          for(let i=0;i<this.employees.length;i++){
            let print=this.employees[i];
            if(id==print.id){
              foundIndex=i;
              break;
            }
          }
          this.employees.splice(foundIndex,1)
        }
      
      
  add(data:any){
    this.employees.push(data);
  }
}
export class Employee{
  id:number;
  name:string;
  designation:string;
  address:string;
  contact:string;
  salary:number;
  constructor(id:number,
name:string,designation:string,address:string,contact:string,salary:number){
  this.id=id;
  this.name=name;
  this.designation=designation;
  this.address=address;
  this.contact=contact;
  this.salary=salary;


    }
}